package com.tiendasara.demo.services;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tiendasara.demo.models.Category;


public interface CategoryRepository extends JpaRepository<Category, Integer>{
    
} 