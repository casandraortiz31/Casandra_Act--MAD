struct Articulo{
    var nombre: String
    var cantidad: Int
}

func registroArticulo() -> Articulo{
    print("Registrar Articulo")
    print("Ingresa el nombre del articulo")
    let nombre = readLine()!
    print("Ingresa la cantidad de existencia")
    let cantidad = Int(readLine()!)!
    return Articulo(nombre: nombre, cantidad: cantidad)
}

func mostrarlistado(articulos: [Articulo]){
    print("Listado de Articulos")
    for (indice, articulo) in articulos.enumerated(){
        print("Articulo \(indice + 1): \(articulo.nombre)")
        print("Cantidad: \(articulo.cantidad)")
    }
}

func consultadeArticulo(articulos: [Articulo]){
    print("Consulta de Articulos")
    print("Ingresa el nombre del articulo a consultar")
    let nombre = readLine()!
    
    var encontrado = false
    
    for (indice, articulo) in articulos.enumerated(){
        if articulo.nombre == nombre{
            print("Articulo \(indice + 1): \(articulo.nombre)")
            print("Cantidad: \(articulo.cantidad)")
            encontrado = true
            break
        }
    }
    
    if !encontrado{
        print("Articulo no encontrado")
    }
}

var articulos: [Articulo] = []
var opcion = 0

repeat {
    print("1. - Registro")
    print("2. - Listado")
    print("3. - Consulta")
    print("4. - Salir")
    print("Selecciona una opcion")
    
    opcion = Int(readLine()!)!
    
    switch opcion{
    case 1:
        print("Registro")
        let nuevoArticulo = registroArticulo()
        articulos.append(nuevoArticulo)
        print("****Articulo registrado******")
        
    case 2:
        print("Listado")
        mostrarlistado(articulos: articulos)
        
    case 3:
        print("Consulta")
        consultadeArticulo(articulos: articulos) // CORREGIDO
        
    case 4:
        print("Salir")
        
    default:
        print("Opcion invalida")
    }
    
} while opcion != 4

